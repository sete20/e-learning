<?php

namespace Brackets\Media\Exceptions\Collections;

use Exception;

class MediaCollectionAlreadyDefined extends Exception
{
}
