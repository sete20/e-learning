@extends('brackets/admin-ui::admin.layout.default')

@section('body')

    Here should be some custom code :)

@endsection