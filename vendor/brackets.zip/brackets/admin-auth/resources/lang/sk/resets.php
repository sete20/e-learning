<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Reset Passwords Lines
    |--------------------------------------------------------------------------
    |
    */

    'email' => [
        'line' => 'Tento email ste dostali pretože sme zaznamenali požiadavku o resetovanie hesla vašeho účtu.',
        'action' => 'Resetovať heslo',
        'notRequested' => 'Ak ste nepožiadali o resetovanie hesla môžete túto správu ignorovať.',
    ],

];
