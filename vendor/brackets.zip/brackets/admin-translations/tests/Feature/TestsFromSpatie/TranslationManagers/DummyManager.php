<?php

namespace Brackets\AdminTranslations\Test\Feature\TestsFromSpatie\TranslationManagers;

use Brackets\AdminTranslations\TranslationLoaderManager;

class DummyManager extends TranslationLoaderManager
{
}
