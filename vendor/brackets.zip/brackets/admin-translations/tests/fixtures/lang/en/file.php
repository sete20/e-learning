<?php

return [
    'key' => 'en value',
    '404' => [
        'title' => 'page not found',
        'message' => 'This page does not exists',
    ],
];
