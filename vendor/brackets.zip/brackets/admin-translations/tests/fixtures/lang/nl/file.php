<?php

return [
    'key' => 'nl value',
    '404' => [
        'title'   => 'pagina niet gevonden',
        'message' => 'Deze pagina bestaat niet',
    ],
];
