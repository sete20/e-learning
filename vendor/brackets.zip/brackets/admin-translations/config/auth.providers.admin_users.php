<?php

return [
    'driver' => 'eloquent',
    'model' => App\User::class,
];
