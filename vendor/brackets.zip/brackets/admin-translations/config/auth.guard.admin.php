<?php

return [
    'driver' => 'session',
    'provider' => 'admin_users',
];
