<?php

return [

    /*
    |
    | This option controls which defaults are used for admin users, used by this package if not present
    |
    */

    'guard' => 'admin',
];
