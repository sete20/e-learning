<?php

namespace Brackets\AdminListing\Exceptions;

use Exception;

class NotAModelClassException extends Exception
{
}
